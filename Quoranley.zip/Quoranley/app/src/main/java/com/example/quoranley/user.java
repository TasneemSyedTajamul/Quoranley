package com.example.quoranley;

public class user {
    private String name;
    private String email;
    private String year;

    public user() {
    }

    public user(String name, String email, String year) {
        this.name = name;
        this.email = email;
        this.year = year;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getYear() {
        return year;
    }


}
