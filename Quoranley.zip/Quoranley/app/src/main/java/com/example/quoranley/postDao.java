package com.example.quoranley;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.Executor;

public class postDao extends AppCompatActivity {

    FirebaseUser u;
    String uid;
    DatabaseReference reference;
    DatabaseReference ref;
    String n, y;
    user User;

    void addPost(String query)
    {

        u= FirebaseAuth.getInstance().getCurrentUser();
        uid= u.getUid();

        //ref= FirebaseDatabase.getInstance().getReference().child("user").child(uid);

        reference= FirebaseDatabase.getInstance().getReference().child("query").child(uid);

        post Post= new post();

        /*ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User= snapshot.getValue(user.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        n= User.getName();
        y=User.getYear();*/

        Post.setText(query);
        /*Post.setCreatedBy(n);
        Post.setYear(y);*/

        long currentTime= System.currentTimeMillis();
        Post.setCreatedAt(currentTime);

        reference.setValue(Post).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                    Toast.makeText(postDao.this, "Query posted successfully", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(postDao.this, "Query posting failed: "+task.getException().toString(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}
