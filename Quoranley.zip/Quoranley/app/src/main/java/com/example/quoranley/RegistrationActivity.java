package com.example.quoranley;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class RegistrationActivity extends AppCompatActivity {

    private EditText name, email, password, year;
    private Button registerBtn;

    private FirebaseAuth mAuth;
    private DatabaseReference reference;
    private ProgressDialog loader;
    private String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name = findViewById(R.id.rName);
        email = findViewById(R.id.rEmail);
        password = findViewById(R.id.rPassword);
        year = findViewById(R.id.rYear);
        registerBtn = findViewById(R.id.registerButton);

        mAuth= FirebaseAuth.getInstance();//initialize

        loader= new ProgressDialog(this);//initialize

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n= name.getText().toString().trim();
                String e= email.getText().toString().trim();
                String p= password.getText().toString().trim();
                String y= year.getText().toString().trim();

                user obj= new user();
                obj.setName(n);
                obj.setEmail(e);
                obj.setYear(y);

                mAuth.createUserWithEmailAndPassword(e, p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful())
                                Toast.makeText(RegistrationActivity.this, "Registration failed: " + task.getException().toString(), Toast.LENGTH_SHORT).show();
                            else {
                                loader.setMessage("Registration in progress");
                                loader.setCanceledOnTouchOutside(false);
                                loader.show();

                                FirebaseUser u= FirebaseAuth.getInstance().getCurrentUser();
                                uid= u.getUid();

                                reference= FirebaseDatabase.getInstance().getReference();
                                reference= reference.child("user");
                                reference.child(uid).setValue(obj);
                                Toast.makeText(RegistrationActivity.this, "Details set successfully", Toast.LENGTH_SHORT).show();
                                loader.dismiss();
                                Intent intent= new Intent(RegistrationActivity.this, HomeActivity.class);
                                startActivity(intent);
                            }
                        }

                    });

            }

            });
    }

    public void goToLogin(View view) {
        Intent intent= new Intent(RegistrationActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}