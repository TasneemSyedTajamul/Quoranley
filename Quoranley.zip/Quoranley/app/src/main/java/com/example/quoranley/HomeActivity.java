package com.example.quoranley;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    TextView askQuery;
    TextView profile;
    ListView listview;
    DatabaseReference reference;
    post Post;
    FirebaseUser u;
    String uid;

    RecyclerView recyclerView;
    DatabaseReference ref;
    MyAdapter adapter;
    ArrayList<String> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        askQuery= findViewById(R.id.askQuery);
        profile= findViewById(R.id.profile);

        askQuery.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(HomeActivity.this, QueryActivity.class);
                startActivity(intent);
            }
        });

        listview= findViewById(R.id.listView);

        u= FirebaseAuth.getInstance().getCurrentUser();
        uid= u.getUid();
        reference= FirebaseDatabase.getInstance().getReference().child("query").child(uid);


        //RecyclerView
        recyclerView= findViewById(R.id.recyclerView);
        ref= FirebaseDatabase.getInstance().getReference().child("query");
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list= new ArrayList<>();
        adapter= new MyAdapter(this, list);
        recyclerView.setAdapter(adapter);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot s: snapshot.getChildren())
                {
                    String p= s.child("text").getValue().toString();
                    list.add(p);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void goToProfile(View view) {
        Intent intent= new Intent(HomeActivity.this, ProfileActivity.class);
        startActivity(intent);
    }
}