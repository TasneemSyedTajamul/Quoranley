package com.example.quoranley;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {

    FirebaseUser u;
    String uid;
    DatabaseReference reference;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        u= FirebaseAuth.getInstance().getCurrentUser();
        uid= u.getUid();

        reference= FirebaseDatabase.getInstance().getReference().child("user").child(uid);

        listView= findViewById(R.id.listView);

        ArrayList<String> list= new ArrayList<String>();
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this, R.layout.list_view, list);
        listView.setAdapter(adapter);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();

                String e= snapshot.child("email").getValue(String.class);
                String n= snapshot.child("name").getValue(String.class);
                String y= snapshot.child("year").getValue(String.class);

                list.add("Email: "+ e);
                list.add("Name: "+ n);
                list.add("Year of study: "+ y);

                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    public void goToHome(View view) {
        Intent intent= new Intent(ProfileActivity.this, HomeActivity.class);
        startActivity(intent);
    }
}