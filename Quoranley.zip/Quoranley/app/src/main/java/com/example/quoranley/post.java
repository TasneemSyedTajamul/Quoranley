package com.example.quoranley;

import java.util.ArrayList;

public class post {
    private String text;
    /*private String createdBy;
    private String year;*/
    private long createdAt;

    public post() {
    }

    public post(String text, String createdBy, String year, long createdAt) {
        this.text = text;
        /*this.createdBy = createdBy;
        this.year = year;*/
        this.createdAt = createdAt;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    /*public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }*/

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

}
