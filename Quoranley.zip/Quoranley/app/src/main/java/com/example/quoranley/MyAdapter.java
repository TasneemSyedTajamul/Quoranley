package com.example.quoranley;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.
        Adapter<MyAdapter.MyViewHolder> {

    ArrayList<String> slist;
    Context context;

    public MyAdapter(Context context, ArrayList<String> slist)
    {
        this.context= context;
        this.slist= slist;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.query_view, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        String Post= slist.get(position);
        /*holder.year.setText(Post.getYear());
        holder.userName.setText(Post.getCreatedBy());
        holder.createdAt.setText((int) Post.getCreatedAt());*/
        holder.query.setText("Question: "+Post);

    }

    @Override
    public int getItemCount() {
        return slist.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        //TextView year, userName;
        TextView createdAt, query;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            /*year= itemView.findViewById(R.id.year);
            userName= itemView.findViewById(R.id.userName);*/
            //createdAt= itemView.findViewById(R.id.createdAt);
            query= itemView.findViewById(R.id.query);

        }
    }

}
